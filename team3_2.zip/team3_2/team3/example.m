clc; clear;

load('c_straight1.mat')
head('calm') ;
Acceleration1=Acceleration
cXacc = Acceleration1.X;
cYacc = Acceleration1.Y;
cZacc = Acceleration1.Z;
caccelDatetimeAcc=Acceleration1.Timestamp;

cXvel = AngularVelocity.X;
cYvel = AngularVelocity.Y;
cZvel = AngularVelocity.Z;
accelDatetimeVel=AngularVelocity.Timestamp;

cXori = Orientation.X;
cYori = Orientation.Y;
cZori = Orientation.Z;
caccelDatetimeOr=Orientation.Timestamp;

load('s_zikzak1.mat')
head('stress') ;
sspeed=Position.speed;
spositionDatetimePos=Position.Timestamp;

sXacc = Acceleration.X;
sYacc = Acceleration.Y;
sZacc = Acceleration.Z;
saccelDatetimeAcc=Acceleration.Timestamp;

sXvel = AngularVelocity.X;
sYvel = AngularVelocity.Y;
sZvel = AngularVelocity.Z;
saccelDatetimeVel=AngularVelocity.Timestamp;

sXori = Orientation.X;
sYori = Orientation.Y;
sZori = Orientation.Z;
saccelDatetimeOr=Orientation.Timestamp;


calmLabel = 'calm  ';
calmLabel = repmat(calmLabel, size(Acceleration1 , 1), 1);
Acceleration1.Activity = calmLabel;


stressLabel = 'stress';
stressLabel = repmat(stressLabel, size(Acceleration, 1), 1);
Acceleration.Activity = stressLabel;

allAcceleration = [Acceleration1; Acceleration];
allAcceleration = timetable2table(allAcceleration, "ConvertRowTimes", false)

load('c_straight2.mat')
justAcc = timetable2table(Acceleration, "ConvertRowTimes", false);
yfit = trainedModel.predictFcn(justAcc)
classificationLearner